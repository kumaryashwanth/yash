package com.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Transaction")
public class Transaction {
	@Column(name= "Transaction_id")
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer transactionid;
	
	@Override
	public String toString() {
		return "Transaction [transactionid=" + transactionid + ", accountid=" + accountid + ", transactiontype="
				+ transactiontype + ", transactionamount=" + transactionamount + ", balance=" + balance + "]";
	}
	public Integer getTransactionid() {
		return transactionid;
	}
	public void setTransactionid(Integer transactionid) {
		this.transactionid = transactionid;
	}
	public Integer getAccountid() {
		return accountid;
	}
	public void setAccountid(Integer accountid) {
		this.accountid = accountid;
	}
	public String getTransactiontype() {
		return transactiontype;
	}
	public void setTransactiontype(String transactiontype) {
		this.transactiontype = transactiontype;
	}
	public Integer getTransactionamount() {
		return transactionamount;
	}
	public void setTransactionamount(Integer transactionamount) {
		this.transactionamount = transactionamount;
	}
	public Integer getBalance() {
		return balance;
	}
	public void setBalance(Integer balance) {
		this.balance = balance;
	}
	public Transaction(Integer accountid, String transactiontype, Integer transactionamount, Integer balance) {
		super();
		this.accountid = accountid;
		this.transactiontype = transactiontype;
		this.transactionamount = transactionamount;
		this.balance = balance;
	}
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Column(name="Account_id", nullable=true, length=20)
	private Integer accountid;
	@Column(name="Transaction_Type", nullable=true, length=225)
	private String transactiontype;
	
	@Column(name="Transaction_Amount", nullable=true, length=20)
	private Integer transactionamount;
	@Column(name="Remaining_Balance", nullable=true,length=20)
	private Integer balance;
	
	
}
