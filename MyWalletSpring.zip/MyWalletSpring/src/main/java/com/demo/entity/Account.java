package com.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="accounts")
public class Account {
	@Column(name="Account_Id")
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer accountid;
	@Column(name="Name", nullable = true, length = 255)
	private String name;
	@Column(name="Mobilenumber", nullable=true,length=10)
	private String mobilenumber;
	@Column(name="Email", nullable=true, length=225)
	private String email;
	@Column(name="Pan", nullable=true, length=20)
	private String pan;
	@Column(name="Account_Type", nullable=true,length=20)
	private String accounttype;
	@Column(name="Balance" ,nullable=true, length=12)
	private Integer balance;
	@Column(name="Branch", nullable=true, length=225)
	private String branch;
	public Account() {
		super();
		
	}
	public Account(String name, String mobilenumber, String email, String pan, String accounttype, Integer balance,
			String branch) {
		super();
		this.name = name;
		this.mobilenumber = mobilenumber;
		this.email = email;
		this.pan = pan;
		this.accounttype = accounttype;
		this.balance = balance;
		this.branch = branch;
	}
	public Integer getAccountid() {
		return accountid;
	}
	public void setAccountid(Integer accountid) {
		this.accountid = accountid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobilenumber() {
		return mobilenumber;
	}
	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public String getAccounttype() {
		return accounttype;
	}
	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}
	public Integer getBalance() {
		return balance;
	}
	public void setBalance(Integer balance) {
		this.balance = balance;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	@Override
	public String toString() {
		return "Account [accountid=" + accountid + ", name=" + name + ", mobilenumber=" + mobilenumber + ", email="
				+ email + ", pan=" + pan + ", accounttype=" + accounttype + ", balance=" + balance + ", branch="
				+ branch + "]";
	}
	
	
	
	
}
