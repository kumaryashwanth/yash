package com.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.TransactionDao;
import com.demo.entity.Transaction;

@Service
public class TransactionService {
	@Autowired
	TransactionDao transactiondao;
	
	public List<Transaction> getAllTransactions(){
		return this.transactiondao.findAll();
	}
	
	public Transaction addTransaction(Transaction transaction) {
		return this.transactiondao.save(transaction);
	}
	public Optional<Transaction> getTransactionById(int transactionid){
		return this.transactiondao.findById( transactionid);
	}
	public Transaction updateTransaction(Transaction transaction) {
		return this.transactiondao.save(transaction);
	}
	
	public void deleteAllTransactions() {
		this.transactiondao.deleteAll();
	}
	public void deleteTransactionById(int transactionid)
	{
		this.transactiondao.deleteById(transactionid);
	}
}
